/**
 * PDF Service
 * PDF 생성, 내보내기 등 PDF 관련 기능
 */

/**
 * 동화책 페이지 데이터 타입
 */
export interface StorybookPage {
  text: string;
  imageUrl?: string;
}

/**
 * 동화책 데이터 타입
 */
export interface StorybookData {
  title: string;
  coverImageUrl?: string;
  pages: StorybookPage[];
}

/**
 * 동화책을 PDF로 생성 및 다운로드
 * @param bookData 동화책 데이터 (제목, 표지, 페이지 배열)
 * @param filename PDF 파일명
 */
export async function generateStorybookPDF(
  bookData: StorybookData,
  filename: string = "storybook.pdf"
): Promise<void> {
  const { jsPDF } = await import("jspdf");
  const fontData = (await import("../assets/fonts/NotoSansKR-Regular")).default;
  
  // A4 세로 방향 (210mm x 297mm)
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  // ⭐ Noto Sans KR 폰트 추가 (한글 지원)
  doc.addFileToVFS("NotoSansKR-Regular.ttf", fontData);
  doc.addFont("NotoSansKR-Regular.ttf", "NotoSansKR", "normal");
  doc.setFont("NotoSansKR");

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 20;
  const contentWidth = pageWidth - 2 * margin;

  let isFirstPage = true;

  // 📕 표지 페이지
  if (bookData.coverImageUrl) {
    try {
      // 제목
      doc.setFontSize(24);
      doc.setFont("NotoSansKR", "normal");
      doc.text(bookData.title, pageWidth / 2, 40, { align: "center" });

      // 표지 이미지
      const coverImg = await loadImageAsDataURL(bookData.coverImageUrl);
      const imgWidth = contentWidth * 0.8;
      const imgHeight = (imgWidth * 3) / 4; // 4:3 비율
      const imgX = (pageWidth - imgWidth) / 2;
      const imgY = 60;
      
      doc.addImage(coverImg, "PNG", imgX, imgY, imgWidth, imgHeight);

      isFirstPage = false;
    } catch (error) {
      console.error("표지 이미지 로드 오류:", error);
    }
  } else {
    // 표지 이미지 없을 때 - 제목만
    doc.setFontSize(28);
    doc.setFont("NotoSansKR", "normal");
    doc.text(bookData.title, pageWidth / 2, pageHeight / 2, { align: "center" });
    
    isFirstPage = false;
  }

  // 📄 내용 페이지들
  for (let i = 0; i < bookData.pages.length; i++) {
    const page = bookData.pages[i];
    
    if (!isFirstPage) {
      doc.addPage();
    }
    isFirstPage = false;

    // 페이지 번호
    doc.setFontSize(12);
    doc.setFont("NotoSansKR", "normal");
    doc.text(`${i + 1}`, pageWidth / 2, margin, { align: "center" });

    let currentY = margin + 10;

    // 페이지 이미지
    if (page.imageUrl) {
      try {
        const pageImg = await loadImageAsDataURL(page.imageUrl);
        const imgWidth = contentWidth * 0.9;
        const imgHeight = (imgWidth * 3) / 4; // 4:3 비율
        const imgX = (pageWidth - imgWidth) / 2;
        
        doc.addImage(pageImg, "PNG", imgX, currentY, imgWidth, imgHeight);
        currentY += imgHeight + 10;
      } catch (error) {
        console.error(`페이지 ${i + 1} 이미지 로드 오류:`, error);
      }
    }

    // 페이지 텍스트
    doc.setFontSize(14);
    doc.setFont("NotoSansKR", "normal");
    
    // 텍스트를 여러 줄로 분할
    const lines = doc.splitTextToSize(page.text, contentWidth);
    
    // 페이지를 벗어나지 않도록 체크
    const lineHeight = 7;
    const maxY = pageHeight - margin;
    
    for (const line of lines) {
      if (currentY + lineHeight > maxY) {
        doc.addPage();
        currentY = margin + 10;
      }
      doc.text(line, margin, currentY);
      currentY += lineHeight;
    }
  }

  // PDF 저장
  doc.save(filename);
}

/**
 * 이미지 URL을 Data URL로 로드
 * @param imageUrl 이미지 URL
 * @returns Data URL
 */
async function loadImageAsDataURL(imageUrl: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        reject(new Error("Canvas context를 가져올 수 없습니다."));
        return;
      }
      
      ctx.drawImage(img, 0, 0);
      const dataURL = canvas.toDataURL("image/png");
      resolve(dataURL);
    };
    
    img.onerror = () => {
      reject(new Error("이미지를 로드할 수 없습니다."));
    };
    
    img.src = imageUrl;
  });
}

/**
 * 스토리북을 PDF로 생성 (간단 버전)
 * @param pages [{ text: string, image: base64 string }]
 * @param filename PDF 파일명
 */
export async function exportStorybookToPDF(
  pages: Array<{ text: string; image?: string | null }>,
  filename: string = "storybook.pdf"
): Promise<void> {
  const jsPDF = (await import("jspdf")).default;
  
  const doc = new jsPDF({
    unit: "pt",
    format: "a4",
  });

  pages.forEach((page, index) => {
    if (index !== 0) doc.addPage();

    // 페이지 제목
    doc.setFont("Helvetica", "bold");
    doc.setFontSize(20);
    doc.text(`페이지 ${index + 1}`, 40, 50);

    // 이미지가 있다면 삽입
    if (page.image) {
      try {
        doc.addImage(page.image, "PNG", 40, 80, 350, 260); // 자동 크기 조정
      } catch (e) {
        console.warn("이미지 삽입 실패:", e);
      }
    }

    // 텍스트 삽입 (여백 넓게)
    doc.setFont("Helvetica", "normal");
    doc.setFontSize(14);

    const textY = page.image ? 360 : 100;

    const splitText = doc.splitTextToSize(page.text, 500);
    doc.text(splitText, 40, textY);
  });

  // 파일 다운로드
  doc.save(filename);
}

/**
 * PDF 미리보기 (준비 중)
 * @param bookData 동화책 데이터
 * @returns PDF Blob
 */
export async function previewStorybookPDF(bookData: StorybookData): Promise<Blob> {
  // TODO: PDF를 Blob으로 반환하여 미리보기 구현
  throw new Error("PDF 미리보기 기능은 준비 중입니다.");
}

/**
 * PDF 설정 옵션
 */
export interface PDFOptions {
  pageSize?: "a4" | "letter" | "legal";
  orientation?: "portrait" | "landscape";
  margin?: number;
  fontSize?: {
    title?: number;
    content?: number;
  };
  includePageNumbers?: boolean;
  watermark?: string;
}

/**
 * 고급 PDF 생성 옵션
 */
export interface EnhancedPDFOptions {
  pages: { text: string; image?: string | null }[];
  title: string;
  author: string;
  layout: "vertical" | "horizontal";
  usePastelBackground: boolean;
  textImageLayout: "image-left" | "image-top";
  coverImage?: string | null;
  bookMode?: boolean;  // 제본 여백 모드
  pageSize?: "a4" | "a5";  // 페이지 크기
}

/**
 * 고급 설정으로 PDF 생성 (준비 중)
 * @param bookData 동화책 데이터
 * @param options PDF 설정 옵션
 * @param filename 파일명
 */
export async function generateStorybookPDFWithOptions(
  bookData: StorybookData,
  options: PDFOptions,
  filename: string = "storybook.pdf"
): Promise<void> {
  // TODO: 고급 옵션 지원
  throw new Error("고급 PDF 생성 기능은 준비 중입니다.");
}

/**
 * 강화된 PDF 생성기 - 출판용 그림 동화책
 * Book Mode: 제본 여백 지원, 가로형 레이아웃 최적화
 * @param options 고급 PDF 생성 옵션
 */
export async function exportEnhancedPDF(options: EnhancedPDFOptions): Promise<void> {
  const { default: jsPDF } = await import("jspdf");

  const {
    pages,
    title,
    author,
    layout,
    usePastelBackground,
    textImageLayout,
    coverImage,
    bookMode = true,  // 기본값: Book Mode 활성화
    pageSize = "a4",   // 기본값: A4
  } = options;

  // === 1. PDF 설정 ===
  const doc = new jsPDF({
    orientation: layout === "horizontal" ? "landscape" : "portrait",
    unit: "pt",
    format: pageSize,
  });

  const width = doc.internal.pageSize.getWidth();
  const height = doc.internal.pageSize.getHeight();
  
  // === 제본 여백 설정 (Book Mode) ===
  // 짝수 페이지(왼쪽): 오른쪽 여백 증가
  // 홀수 페이지(오른쪽): 왼쪽 여백 증가
  const baseMargin = 40;  // 기본 여백
  const gutterMargin = 60;  // 제본 안쪽 여백 (더 큼)
  
  const getMargins = (pageNumber: number) => {
    if (!bookMode) {
      return { left: baseMargin, right: baseMargin, top: baseMargin, bottom: baseMargin };
    }
    
    const isEvenPage = pageNumber % 2 === 0;
    return {
      left: isEvenPage ? baseMargin : gutterMargin,   // 홀수 페이지는 왼쪽 여백 증가
      right: isEvenPage ? gutterMargin : baseMargin,  // 짝수 페이지는 오른쪽 여백 증가
      top: baseMargin,
      bottom: baseMargin
    };
  };

  // ⭐ html2canvas를 사용하여 한글 텍스트를 이미지로 렌더링
  const html2canvas = (await import("html2canvas")).default;

  // ⭐ 파스텔톤 색상 목록
  const pastelColors = [
    "#FBE4E6", // 은은한 핑크
    "#E8F0FE", // 파스텔 블루
    "#EAF8E6", // 연녹색
    "#FFF4CC", // 크림
    "#F9EBFF", // 연보라
  ];

  // ======================================================
  // ===== 2. 표지 페이지 생성 (HTML로 렌더링하여 한글 지원) =====
  // ======================================================

  // 표지 페이지를 HTML로 생성
  const coverDiv = document.createElement('div');
  coverDiv.style.width = `${width}px`;
  coverDiv.style.height = `${height}px`;
  coverDiv.style.position = 'fixed';
  coverDiv.style.left = '-9999px';
  coverDiv.style.top = '0';
  coverDiv.style.backgroundColor = usePastelBackground ? '#E8F0FE' : '#ffffff';
  coverDiv.style.display = 'flex';
  coverDiv.style.flexDirection = 'column';
  coverDiv.style.alignItems = 'center';
  coverDiv.style.justifyContent = 'center';
  coverDiv.style.fontFamily = '"Noto Sans KR", "Malgun Gothic", "Apple SD Gothic Neo", sans-serif';
  
  // 표지 이미지 추가
  if (coverImage) {
    const imgEl = document.createElement('img');
    imgEl.src = coverImage;
    imgEl.style.width = `${width - 200}px`;
    imgEl.style.height = `${height / 2}px`;
    imgEl.style.objectFit = 'contain';
    imgEl.style.marginBottom = '40px';
    coverDiv.appendChild(imgEl);
  }
  
  // 제목
  const titleEl = document.createElement('div');
  titleEl.textContent = title;
  titleEl.style.fontSize = '32px';
  titleEl.style.fontWeight = 'bold';
  titleEl.style.textAlign = 'center';
  titleEl.style.marginTop = coverImage ? '20px' : '0';
  titleEl.style.color = '#000000';
  coverDiv.appendChild(titleEl);
  
  // 저자명
  const authorEl = document.createElement('div');
  authorEl.textContent = `저자: ${author}`;
  authorEl.style.fontSize = '18px';
  authorEl.style.textAlign = 'center';
  authorEl.style.marginTop = '20px';
  authorEl.style.color = '#666666';
  coverDiv.appendChild(authorEl);
  
  document.body.appendChild(coverDiv);
  
  try {
    // HTML을 캔버스로 렌더링
    const coverCanvas = await html2canvas(coverDiv, {
      width: width,
      height: height,
      scale: 2,
      backgroundColor: usePastelBackground ? '#E8F0FE' : '#ffffff'
    });
    const coverImgData = coverCanvas.toDataURL('image/png');
    doc.addImage(coverImgData, 'PNG', 0, 0, width, height);
  } catch (error) {
    console.error('표지 렌더링 오류:', error);
    // 폴백: 기본 배경만 추가
    if (usePastelBackground) {
      doc.setFillColor("#E8F0FE");
      doc.rect(0, 0, width, height, "F");
    }
  } finally {
    document.body.removeChild(coverDiv);
  }

  // ======================================================
  // ===== 3. 본문 페이지 생성 - 출판용 그림책 레이아웃 =====
  // ======================================================

  // 각 페이지를 HTML로 렌더링
  for (let index = 0; index < pages.length; index++) {
    const page = pages[index];
    const pageNumber = index + 2;  // 표지 = 1, 본문 = 2부터
    doc.addPage();

    // 제본 여백 적용
    const margins = getMargins(pageNumber);

    // 페이지를 HTML로 생성
    const pageDiv = document.createElement('div');
    pageDiv.style.width = `${width}px`;
    pageDiv.style.height = `${height}px`;
    pageDiv.style.position = 'fixed';
    pageDiv.style.left = '-9999px';
    pageDiv.style.top = '0';
    pageDiv.style.fontFamily = '"Noto Sans KR", "Pretendard", "Malgun Gothic", sans-serif';
    
    // 배경색
    if (usePastelBackground) {
      const bg = pastelColors[index % pastelColors.length];
      pageDiv.style.backgroundColor = bg;
    } else {
      pageDiv.style.backgroundColor = '#ffffff';
    }
    
    // 페이지 번호 (하단 중앙, 작은 크기)
    const pageNumEl = document.createElement('div');
    pageNumEl.textContent = `– ${index + 1} –`;
    pageNumEl.style.fontSize = '12px';
    pageNumEl.style.position = 'absolute';
    pageNumEl.style.left = '0';
    pageNumEl.style.right = '0';
    pageNumEl.style.bottom = '20px';
    pageNumEl.style.textAlign = 'center';
    pageNumEl.style.color = '#999999';
    pageDiv.appendChild(pageNumEl);
    
    // === 가로형 레이아웃: 왼쪽 55~60% 그림, 오른쪽 40~45% 글 ===
    if (textImageLayout === "image-left") {
      const imageWidth = width * 0.55;  // 그림 영역 55%
      const textWidth = width * 0.40;   // 텍스트 영역 40%
      const gap = width * 0.05;         // 중간 간격 5%
      
      if (page.image) {
        // 이미지 왼쪽
        const imgEl = document.createElement('img');
        imgEl.src = page.image;
        imgEl.style.position = 'absolute';
        imgEl.style.left = `${margins.left}px`;
        imgEl.style.top = `${margins.top + 20}px`;
        imgEl.style.width = `${imageWidth - margins.left - gap}px`;
        imgEl.style.height = `${height - margins.top - margins.bottom - 60}px`;
        imgEl.style.objectFit = 'contain';
        pageDiv.appendChild(imgEl);
      }
      
      // 텍스트 오른쪽
      const textEl = document.createElement('div');
      textEl.textContent = page.text;
      textEl.style.position = 'absolute';
      textEl.style.left = `${imageWidth + gap}px`;
      textEl.style.top = `${margins.top + 40}px`;
      textEl.style.width = `${textWidth - margins.right}px`;
      textEl.style.height = `${height - margins.top - margins.bottom - 80}px`;
      textEl.style.fontSize = '16px';      // 14~16pt
      textEl.style.lineHeight = '1.8';     // 넉넉한 줄 간격
      textEl.style.color = '#000000';
      textEl.style.whiteSpace = 'pre-wrap';
      textEl.style.wordWrap = 'break-word';
      textEl.style.display = 'flex';
      textEl.style.alignItems = 'center';  // 세로 중앙 정렬
      textEl.style.padding = '0 20px';
      pageDiv.appendChild(textEl);
      
    } 
    // === 세로형 레이아웃: 위쪽 그림, 아래쪽 글 ===
    else if (textImageLayout === "image-top") {
      const imageHeight = height * 0.50;  // 그림 영역 50%
      const textHeight = height * 0.40;   // 텍스트 영역 40%
      
      if (page.image) {
        // 이미지 위쪽
        const imgEl = document.createElement('img');
        imgEl.src = page.image;
        imgEl.style.position = 'absolute';
        imgEl.style.left = `${margins.left}px`;
        imgEl.style.top = `${margins.top + 20}px`;
        imgEl.style.width = `${width - margins.left - margins.right}px`;
        imgEl.style.height = `${imageHeight - margins.top - 40}px`;
        imgEl.style.objectFit = 'contain';
        pageDiv.appendChild(imgEl);
      }
      
      // 텍스트 아래쪽
      const textEl = document.createElement('div');
      textEl.textContent = page.text;
      textEl.style.position = 'absolute';
      textEl.style.left = `${margins.left + 20}px`;
      textEl.style.top = `${imageHeight + 20}px`;
      textEl.style.width = `${width - margins.left - margins.right - 40}px`;
      textEl.style.height = `${textHeight - 40}px`;
      textEl.style.fontSize = '16px';
      textEl.style.lineHeight = '1.8';
      textEl.style.color = '#000000';
      textEl.style.whiteSpace = 'pre-wrap';
      textEl.style.wordWrap = 'break-word';
      textEl.style.padding = '20px';
      pageDiv.appendChild(textEl);
    }
    
    document.body.appendChild(pageDiv);
    
    try {
      // HTML을 고해상도 캔버스로 렌더링
      const pageCanvas = await html2canvas(pageDiv, {
        width: width,
        height: height,
        scale: 2,  // 고해상도
        backgroundColor: usePastelBackground ? pastelColors[index % pastelColors.length] : '#ffffff',
        useCORS: true,
        allowTaint: true
      });
      const pageImgData = pageCanvas.toDataURL('image/png');
      doc.addImage(pageImgData, 'PNG', 0, 0, width, height);
    } catch (error) {
      console.error(`페이지 ${index + 1} 렌더링 오류:`, error);
    } finally {
      document.body.removeChild(pageDiv);
    }
  }

  // ======================================================
  // ===== 4. 파일 저장 =====================================
  // ======================================================

  doc.save(`${title}.pdf`);
}

/**
 * 간단한 PDF 생성 함수
 * @param items 작품 배열 (title, image, description)
 */
export async function makePDF(items: Array<{
  title?: string;
  image?: string;
  description?: string;
}>): Promise<void> {
  const { default: jsPDF } = await import("jspdf");
  
  const pdf = new jsPDF({
    unit: "pt",
    format: "a4",
  });

  items.forEach((item, index) => {
    if (index !== 0) pdf.addPage();

    // 제목
    pdf.setFontSize(20);
    pdf.text(item.title || "작품 제목 없음", 40, 60);

    // 이미지
    if (item.image) {
      try {
        pdf.addImage(item.image, "JPEG", 40, 100, 500, 500);
      } catch (error) {
        console.error(`이미지 ${index + 1} 추가 오류:`, error);
      }
    }

    // 설명
    pdf.setFontSize(14);
    const lines = pdf.splitTextToSize(item.description || "", 500);
    pdf.text(lines, 40, 630);
  });

  pdf.save("my_storybook.pdf");
}

/**
 * Story 타입 (html2canvas 기반 PDF용)
 */
export interface Story {
  id: string;
  title: string;
  image?: string;
  description?: string;
  content?: string;
}

/**
 * PDF 옵션 인터페이스
 */
export interface StoryPDFOptions {
  margin?: "small" | "normal" | "large";
  fontSize?: "small" | "medium" | "large";
  layout?: "A" | "B" | "C";  // A: 그림 위/글 아래, B: 그림 전체, C: 그림/글 반반
}

/**
 * 레이아웃 기반 Story PDF 생성
 * @param story Story 데이터
 * @param options PDF 생성 옵션
 */
export async function generateStoryPDF(
  story: Story,
  options: StoryPDFOptions = {}
): Promise<void> {
  const { default: jsPDF } = await import("jspdf");

  const layout = options.layout || "A";
  const textContent = story.description || story.content || "";

  const pdf = new jsPDF({ format: "a4", unit: "px" });

  // -------------------------
  // A안: 그림 위 + 글 아래
  // -------------------------
  if (layout === "A") {
    // 제목
    pdf.setFontSize(20);
    pdf.setTextColor("#333");
    pdf.text(story.title, 297, 60, { align: "center" });

    // 이미지
    if (story.image) {
      try {
        const img = await loadImageForPDF(story.image);
        pdf.addImage(img, "JPEG", 50, 90, 495, 350, undefined, "FAST");
      } catch (error) {
        console.error("이미지 로드 오류:", error);
      }
    }

    // 텍스트
    pdf.setFontSize(16);
    pdf.setTextColor("#000");
    if (textContent) {
      const lines = pdf.splitTextToSize(textContent, 495);
      pdf.text(lines, 50, 470);
    }

    pdf.save(`Story_A_${story.title}.pdf`);
    return;
  }

  // -------------------------
  // B안: 이미지 한 페이지 전체
  // -------------------------
  if (layout === "B") {
    if (story.image) {
      try {
        const img = await loadImageForPDF(story.image);
        pdf.addImage(img, "JPEG", 0, 0, 595, 842, undefined, "FAST"); // 전체 페이지
      } catch (error) {
        console.error("이미지 로드 오류:", error);
      }
    }

    // 텍스트는 다음 페이지에
    pdf.addPage();

    pdf.setFontSize(18);
    pdf.setTextColor("#000");
    if (textContent) {
      const lines = pdf.splitTextToSize(textContent, 495);
      pdf.text(lines, 50, 60);
    }

    pdf.save(`Story_B_${story.title}.pdf`);
    return;
  }

  // -------------------------
  // C안: 그림/글 반반 (상하 배치)
  // -------------------------
  if (layout === "C") {
    if (story.image) {
      try {
        const img = await loadImageForPDF(story.image);
        pdf.addImage(img, "JPEG", 50, 50, 495, 300, undefined, "FAST"); // 상단 이미지
      } catch (error) {
        console.error("이미지 로드 오류:", error);
      }
    }

    // 텍스트는 하단에
    pdf.setFontSize(16);
    pdf.setTextColor("#000");
    if (textContent) {
      const lines = pdf.splitTextToSize(textContent, 495);
      pdf.text(lines, 50, 380);
    }

    pdf.save(`Story_C_${story.title}.pdf`);
    return;
  }

  // 기본값 (A안)
  pdf.save(`Story_${story.title}.pdf`);
}

/**
 * 이미지 로드 헬퍼 함수 (Promise 기반)
 * @param src 이미지 소스 URL
 * @returns Image 객체
 */
function loadImageForPDF(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("이미지 로드 실패"));
    img.src = src;
  });
}

export default {
  generateStorybookPDF,
  exportStorybookToPDF,
  exportEnhancedPDF,
  previewStorybookPDF,
  generateStorybookPDFWithOptions,
  makePDF,
  generateStoryPDF,
};
